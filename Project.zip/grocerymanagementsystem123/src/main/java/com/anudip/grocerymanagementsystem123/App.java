package com.anudip.grocerymanagementsystem123;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;



/**
 * Hello world!
 *
 */
public class App 
{
	
    public static void main( String[] args )
    {
    	Configuration conf = new Configuration().configure().addAnnotatedClass(Product.class) .addAnnotatedClass(Order_Item.class);
                

        try (SessionFactory sFactory = conf.buildSessionFactory();
             Session session = sFactory.openSession()) {
            
            Transaction transaction = session.beginTransaction();

            // Create and save Product objects
            Product p1 = new Product();
            p1.setPid(1); // Set unique ID for p1
            p1.setPname("Apple");
            p1.setPprice(120);
            session.save(p1);

            Product p2 = new Product();
            p2.setPid(2); // Set unique ID for p2
            p2.setPname("Guava");
            p2.setPprice(200);
            session.save(p2);

            // Create and save Order_Item object
            Order_Item o1 = new Order_Item();
            o1.setOid(101);
            o1.setOquantity(2);
            //o1.setProduct(p1); // Set product for order item
            session.save(o1);

            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
