package com.anudip.grocerymanagementsystem123;

import javax.persistence.CascadeType;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
@Table(name="Product_List")

public class Product {
	@Id
	private int pid;
	private String pname;
	private int pprice;
	@OneToMany(mappedBy = "product", cascade = CascadeType.ALL)
	List<Order_Item> Order_Item;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPprice() {
		return pprice;
	}
	public void setPprice(int pprice) {
		this.pprice = pprice;
	}
	public Product() {
		
		// TODO Auto-generated constructor stub
	}
	
	

}
